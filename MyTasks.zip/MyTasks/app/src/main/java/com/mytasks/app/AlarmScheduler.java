package com.mytasks.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;

import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Books each task's next ring with the system, so it rings even with the phone locked or the app closed. */
public class AlarmScheduler {
    public static final String ACTION_FIRE = "com.mytasks.app.FIRE";

    static PendingIntent firePi(Context c, long id, boolean snooze) {
        Intent i = new Intent(c, AlarmReceiver.class)
                .setAction(ACTION_FIRE)
                .setData(Uri.parse("task://" + id + (snooze ? "/snooze" : "")))
                .putExtra("id", id)
                .putExtra("snooze", snooze);
        return PendingIntent.getBroadcast(c, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static boolean canExact(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
    }

    private static void set(Context c, long when, PendingIntent pi) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (canExact(c)) {
            PendingIntent show = PendingIntent.getActivity(c, 0,
                    new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(when, show), pi);
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    /** Next time this task should ring, or null if never. */
    public static Long nextTrigger(Task t) {
        if (!t.hasTime()) return null;
        long now = System.currentTimeMillis();
        Calendar d = Calendar.getInstance();
        for (int i = 0; i < 400; i++) {
            String k = Util.key(d);
            if (!t.daily && k.compareTo(t.date) > 0) return null;
            if (t.appliesTo(k) && !t.isDone(k)) {
                long due = Util.dueAt(k, t.hour, t.minute);
                if (due > now) return due;
            }
            d.add(Calendar.DAY_OF_MONTH, 1);
        }
        return null;
    }

    public static synchronized void rescheduleAll(Context c) {
        List<Task> tasks = TaskStore.load(c);
        SharedPreferences p = c.getSharedPreferences("alarms", Context.MODE_PRIVATE);
        Set<String> old = new HashSet<>(p.getStringSet("ids", new HashSet<>()));
        Set<String> booked = new HashSet<>();
        for (Task t : tasks) {
            Long when = nextTrigger(t);
            if (when != null) {
                set(c, when, firePi(c, t.id, false));
                booked.add(String.valueOf(t.id));
            }
        }
        old.removeAll(booked);
        for (String s : old) {
            try {
                cancel(c, Long.parseLong(s));
            } catch (NumberFormatException ignored) {
            }
        }
        p.edit().putStringSet("ids", booked).apply();
    }

    public static void cancel(Context c, long id) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        am.cancel(firePi(c, id, false));
        am.cancel(firePi(c, id, true));
    }

    public static void snooze(Context c, long id, int minutes) {
        set(c, System.currentTimeMillis() + minutes * 60_000L, firePi(c, id, true));
    }
}
