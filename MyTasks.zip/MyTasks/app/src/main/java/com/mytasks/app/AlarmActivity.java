package com.mytasks.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/** Full-screen ringing page that shows over the lock screen. */
public class AlarmActivity extends Activity {
    private long id;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_alarm);

        Button done = findViewById(R.id.btnDone);
        Button snooze = findViewById(R.id.btnSnooze);
        Button stop = findViewById(R.id.btnStop);
        snooze.setText("غفوة " + Util.ar(String.valueOf(AlarmReceiver.SNOOZE_MIN)) + " دقايق");

        done.setOnClickListener(v -> {
            AlarmReceiver.stop(this, id);
            AlarmReceiver.markDone(this, id);
            Toast.makeText(this, "عاش! اتعلّمت إنها خلصت", Toast.LENGTH_SHORT).show();
            finish();
        });
        snooze.setOnClickListener(v -> {
            AlarmReceiver.stop(this, id);
            AlarmScheduler.snooze(this, id, AlarmReceiver.SNOOZE_MIN);
            Toast.makeText(this, "هفكّرك تاني بعد " + Util.ar(String.valueOf(AlarmReceiver.SNOOZE_MIN)) + " دقايق", Toast.LENGTH_SHORT).show();
            finish();
        });
        stop.setOnClickListener(v -> {
            AlarmReceiver.stop(this, id);
            finish();
        });
        bind(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        bind(intent);
    }

    private void bind(Intent i) {
        id = i.getLongExtra("id", -1);
        Task t = TaskStore.find(this, id);
        ((TextView) findViewById(R.id.tvTitle)).setText(t != null ? t.title : "مهمة");
        ((TextView) findViewById(R.id.tvTime)).setText(
                t != null && t.hasTime() ? Util.fmtTime(t.hour, t.minute) : "");
    }
}
