package com.mytasks.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** One task. date = the day it was added for (yyyy-MM-dd); daily tasks repeat from that day on. */
public class Task {
    public long id;
    public String title = "";
    public int hour = -1;
    public int minute = -1;
    public String date = "";
    public boolean daily;
    public Set<String> doneOn = new HashSet<>();

    public boolean hasTime() {
        return hour >= 0 && minute >= 0;
    }

    public boolean isDone(String day) {
        return doneOn.contains(day);
    }

    /** Is this task on the list for the given day? */
    public boolean appliesTo(String day) {
        return daily ? day.compareTo(date) >= 0 : day.equals(date);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("title", title);
        o.put("hour", hour);
        o.put("minute", minute);
        o.put("date", date);
        o.put("daily", daily);
        List<String> days = new ArrayList<>(doneOn);
        Collections.sort(days);
        if (days.size() > 60) days = days.subList(days.size() - 60, days.size());
        JSONArray a = new JSONArray();
        for (String d : days) a.put(d);
        o.put("doneOn", a);
        return o;
    }

    public static Task fromJson(JSONObject o) {
        Task t = new Task();
        t.id = o.optLong("id");
        t.title = o.optString("title", "");
        t.hour = o.optInt("hour", -1);
        t.minute = o.optInt("minute", -1);
        t.date = o.optString("date", "");
        t.daily = o.optBoolean("daily", false);
        JSONArray a = o.optJSONArray("doneOn");
        if (a != null) for (int i = 0; i < a.length(); i++) t.doneOn.add(a.optString(i));
        return t;
    }
}
