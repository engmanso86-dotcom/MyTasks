package com.mytasks.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final Calendar selected = Calendar.getInstance();
    private int pickH = -1, pickM = -1;
    private final List<Task> shown = new ArrayList<>();

    private TextView tvDate, tvCount, banner, tvEmpty;
    private EditText etTitle;
    private Button btnTime;
    private CheckBox cbDaily;
    private TaskAdapter adapter;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        tvDate = findViewById(R.id.tvDate);
        tvCount = findViewById(R.id.tvCount);
        banner = findViewById(R.id.banner);
        tvEmpty = findViewById(R.id.tvEmpty);
        etTitle = findViewById(R.id.etTitle);
        btnTime = findViewById(R.id.btnTime);
        cbDaily = findViewById(R.id.cbDaily);
        ListView list = findViewById(R.id.list);
        adapter = new TaskAdapter();
        list.setAdapter(adapter);
        list.setEmptyView(tvEmpty);

        findViewById(R.id.btnPrev).setOnClickListener(v -> { selected.add(Calendar.DAY_OF_MONTH, -1); refresh(); });
        findViewById(R.id.btnNext).setOnClickListener(v -> { selected.add(Calendar.DAY_OF_MONTH, 1); refresh(); });
        tvDate.setOnClickListener(v -> { selected.setTimeInMillis(System.currentTimeMillis()); refresh(); });

        btnTime.setOnClickListener(v -> {
            Calendar now = Calendar.getInstance();
            int h = pickH >= 0 ? pickH : now.get(Calendar.HOUR_OF_DAY);
            int m = pickM >= 0 ? pickM : now.get(Calendar.MINUTE);
            new TimePickerDialog(this, (tp, hh, mm) -> {
                pickH = hh;
                pickM = mm;
                btnTime.setText("⏰ " + Util.fmtTime(hh, mm));
            }, h, m, false).show();
        });

        findViewById(R.id.btnAdd).setOnClickListener(v -> addTask());

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        updateBanner();
        AlarmScheduler.rescheduleAll(this);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        updateBanner();
    }

    private void addTask() {
        String title = etTitle.getText().toString().trim();
        if (title.isEmpty()) {
            etTitle.setError("اكتب اسم المهمة");
            return;
        }
        List<Task> all = TaskStore.load(this);
        Task t = new Task();
        t.id = System.currentTimeMillis();
        t.title = title;
        t.hour = pickH;
        t.minute = pickM;
        t.date = Util.key(selected);
        t.daily = cbDaily.isChecked();
        all.add(t);
        TaskStore.save(this, all);
        AlarmScheduler.rescheduleAll(this);

        etTitle.setText("");
        pickH = pickM = -1;
        btnTime.setText("⏰ الوقت");
        cbDaily.setChecked(false);
        refresh();

        Long next = AlarmScheduler.nextTrigger(t);
        if (next != null) {
            Toast.makeText(this, "هيرن الساعة " + Util.fmtTime(t.hour, t.minute), Toast.LENGTH_SHORT).show();
        } else if (t.hasTime()) {
            Toast.makeText(this, "الوقت ده فات، مش هيرن", Toast.LENGTH_LONG).show();
        }
    }

    private void refresh() {
        String day = Util.key(selected);
        shown.clear();
        for (Task t : TaskStore.load(this)) if (t.appliesTo(day)) shown.add(t);
        shown.sort((a, c) -> {
            int ta = a.hasTime() ? a.hour * 60 + a.minute : 9999;
            int tc = c.hasTime() ? c.hour * 60 + c.minute : 9999;
            return Integer.compare(ta, tc);
        });

        String label = new SimpleDateFormat("EEEE d MMMM", new Locale("ar", "EG")).format(selected.getTime());
        String today = Util.today();
        Calendar tmr = Calendar.getInstance();
        tmr.add(Calendar.DAY_OF_MONTH, 1);
        Calendar yst = Calendar.getInstance();
        yst.add(Calendar.DAY_OF_MONTH, -1);
        if (day.equals(today)) label = "النهارده • " + label;
        else if (day.equals(Util.key(tmr))) label = "بكرة • " + label;
        else if (day.equals(Util.key(yst))) label = "امبارح • " + label;
        tvDate.setText(Util.ar(label));

        int done = 0;
        for (Task t : shown) if (t.isDone(day)) done++;
        tvCount.setText(Util.ar(done + " من " + shown.size() + " خلصت"));
        adapter.notifyDataSetChanged();
    }

    private void toggleDone(Task t, String day) {
        List<Task> all = TaskStore.load(this);
        Task s = TaskStore.find(all, t.id);
        if (s == null) return;
        if (s.isDone(day)) s.doneOn.remove(day);
        else s.doneOn.add(day);
        TaskStore.save(this, all);
        AlarmScheduler.rescheduleAll(this);
        refresh();
    }

    private void confirmDelete(Task t) {
        new AlertDialog.Builder(this)
                .setMessage("تمسح «" + t.title + "»؟" + (t.daily ? "\nدي مهمة يومية، هتتمسح من كل الأيام." : ""))
                .setPositiveButton("امسح", (d, w) -> {
                    List<Task> all = TaskStore.load(this);
                    Task s = TaskStore.find(all, t.id);
                    if (s != null) all.remove(s);
                    TaskStore.save(this, all);
                    AlarmScheduler.cancel(this, t.id);
                    AlarmReceiver.stop(this, t.id);
                    AlarmScheduler.rescheduleAll(this);
                    refresh();
                })
                .setNegativeButton("لأ", null)
                .show();
    }

    // ---- Permission banner: shows the first thing still blocking the alarm ----
    private void updateBanner() {
        String pkg = getPackageName();
        NotificationManager nm = getSystemService(NotificationManager.class);
        PowerManager pm = getSystemService(PowerManager.class);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            showBanner("⚠️ اسمح بالإشعارات عشان التنبيه يرن. دوس هنا.", () ->
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1));
        } else if (!nm.areNotificationsEnabled()) {
            showBanner("⚠️ الإشعارات مقفولة للتطبيق. دوس هنا وافتحها.", () ->
                    open(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, pkg)));
        } else if (!AlarmScheduler.canExact(this)) {
            showBanner("⚠️ اسمح بـ«المنبهات والتذكيرات» عشان يرن في الوقت بالظبط. دوس هنا.", () ->
                    open(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + pkg))));
        } else if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent()) {
            showBanner("⚠️ اسمح للتنبيه يظهر على الشاشة المقفولة. دوس هنا.", () ->
                    open(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + pkg))));
        } else if (!pm.isIgnoringBatteryOptimizations(pkg)) {
            showBanner("⚠️ اسمح للتطبيق يشتغل في الخلفية عشان البطارية متوقفوش. دوس هنا.", () ->
                    open(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + pkg))));
        } else {
            banner.setVisibility(View.GONE);
        }
    }

    private void showBanner(String text, Runnable onTap) {
        banner.setText(text);
        banner.setVisibility(View.VISIBLE);
        banner.setOnClickListener(v -> onTap.run());
    }

    private void open(Intent i) {
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    // ---- List rows ----
    private class TaskAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int p) { return shown.get(p); }
        @Override public long getItemId(int p) { return shown.get(p).id; }

        @Override
        public View getView(int pos, View v, ViewGroup parent) {
            if (v == null) v = getLayoutInflater().inflate(R.layout.item_task, parent, false);
            Task t = shown.get(pos);
            String day = Util.key(selected);
            boolean done = t.isDone(day);
            boolean late = !done && t.hasTime() && Util.dueAt(day, t.hour, t.minute) < System.currentTimeMillis();

            CheckBox cb = v.findViewById(R.id.cb);
            TextView title = v.findViewById(R.id.tvTitle);
            TextView meta = v.findViewById(R.id.tvMeta);
            ImageButton del = v.findViewById(R.id.btnDel);

            cb.setOnCheckedChangeListener(null);
            cb.setChecked(done);
            cb.setOnCheckedChangeListener((b, c) -> toggleDone(t, day));

            title.setText(t.title);
            title.setPaintFlags(done ? title.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG
                    : title.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            title.setAlpha(done ? 0.5f : 1f);

            StringBuilder m = new StringBuilder();
            if (t.hasTime()) m.append("⏰ ").append(Util.fmtTime(t.hour, t.minute));
            else m.append("من غير وقت");
            if (t.daily) m.append("  •  كل يوم");
            if (late) m.append("  •  متأخرة");
            meta.setText(m.toString());
            meta.setTextColor(getColor(late ? R.color.warn : R.color.muted));

            del.setOnClickListener(x -> confirmDelete(t));
            return v;
        }
    }
}
