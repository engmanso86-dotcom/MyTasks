package com.mytasks.app;

import java.util.Calendar;
import java.util.Locale;

public class Util {
    private static final char[] AR = {'٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'};

    public static String ar(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) b.append(ch >= '0' && ch <= '9' ? AR[ch - '0'] : ch);
        return b.toString();
    }

    public static String key(Calendar c) {
        return String.format(Locale.US, "%04d-%02d-%02d",
                c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    public static String today() {
        return key(Calendar.getInstance());
    }

    /** 19:05 -> ٧:٠٥ م */
    public static String fmtTime(int h, int m) {
        String ap = h < 12 ? "ص" : "م";
        int h12 = h % 12 == 0 ? 12 : h % 12;
        return ar(String.format(Locale.US, "%d:%02d", h12, m)) + " " + ap;
    }

    /** The moment this task is due on the given day, in millis. */
    public static long dueAt(String day, int h, int m) {
        String[] p = day.split("-");
        Calendar c = Calendar.getInstance();
        c.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]), h, m, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }
}
