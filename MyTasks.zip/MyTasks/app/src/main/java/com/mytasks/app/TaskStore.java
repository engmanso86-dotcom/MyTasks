package com.mytasks.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** Saves the task list on the phone. */
public class TaskStore {
    private static final String PREFS = "tasks";
    private static final String KEY = "list";

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized List<Task> load(Context c) {
        List<Task> list = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString(KEY, "[]"));
            for (int i = 0; i < a.length(); i++) list.add(Task.fromJson(a.getJSONObject(i)));
        } catch (JSONException ignored) {
        }
        return list;
    }

    public static synchronized void save(Context c, List<Task> list) {
        JSONArray a = new JSONArray();
        try {
            for (Task t : list) a.put(t.toJson());
        } catch (JSONException ignored) {
        }
        prefs(c).edit().putString(KEY, a.toString()).commit();
    }

    public static Task find(List<Task> list, long id) {
        for (Task t : list) if (t.id == id) return t;
        return null;
    }

    public static Task find(Context c, long id) {
        return find(load(c), id);
    }
}
