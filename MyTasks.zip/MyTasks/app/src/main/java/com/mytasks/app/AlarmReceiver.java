package com.mytasks.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;

import java.util.List;

/** Fires when a task is due: rings like an alarm clock until stopped. */
public class AlarmReceiver extends BroadcastReceiver {
    static final String ACTION_DONE = "com.mytasks.app.DONE";
    static final String ACTION_SNOOZE = "com.mytasks.app.SNOOZE";
    static final String ACTION_STOP = "com.mytasks.app.STOP";
    static final String CHANNEL = "task_alarm_v1";
    static final int SNOOZE_MIN = 5;
    static final long RING_MS = 3 * 60_000L; // stop ringing by itself after 3 minutes

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        long id = i.getLongExtra("id", -1);
        if (AlarmScheduler.ACTION_FIRE.equals(a)) {
            fire(c, id, i.getBooleanExtra("snooze", false));
        } else if (ACTION_DONE.equals(a)) {
            stop(c, id);
            markDone(c, id);
        } else if (ACTION_SNOOZE.equals(a)) {
            stop(c, id);
            AlarmScheduler.snooze(c, id, SNOOZE_MIN);
        } else if (ACTION_STOP.equals(a)) {
            stop(c, id);
        }
    }

    static int nid(long id) {
        return Long.hashCode(id);
    }

    static void ensureChannel(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "تنبيه المهام",
                NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("يرن في وقت كل مهمة");
        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        ch.setSound(sound, new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build());
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 800, 400, 800, 400, 800});
        ch.setBypassDnd(true);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    private PendingIntent action(Context c, long id, String act) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(act)
                .setData(Uri.parse("task://" + id)).putExtra("id", id);
        return PendingIntent.getBroadcast(c, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void fire(Context c, long id, boolean snooze) {
        Task t = TaskStore.find(c, id);
        String today = Util.today();
        if (t == null || (t.isDone(today) && t.appliesTo(today))) {
            AlarmScheduler.rescheduleAll(c);
            return;
        }
        ensureChannel(c);

        Intent full = new Intent(c, AlarmActivity.class)
                .putExtra("id", id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        PendingIntent fullPi = PendingIntent.getActivity(c, nid(id), full,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String when = t.hasTime() ? Util.fmtTime(t.hour, t.minute) : "";
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_alarm)
                .setContentTitle("⏰ " + t.title)
                .setContentText(snooze ? "تذكير بعد الغفوة" : "جه وقت المهمة • " + when)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setFullScreenIntent(fullPi, true)
                .setContentIntent(fullPi)
                .setOngoing(true)
                .setAutoCancel(false)
                .setTimeoutAfter(RING_MS)
                .addAction(new Notification.Action.Builder(null, "خلصتها", action(c, id, ACTION_DONE)).build())
                .addAction(new Notification.Action.Builder(null, "غفوة " + Util.ar(String.valueOf(SNOOZE_MIN)) + " دقايق", action(c, id, ACTION_SNOOZE)).build())
                .addAction(new Notification.Action.Builder(null, "إيقاف", action(c, id, ACTION_STOP)).build())
                .build();
        n.flags |= Notification.FLAG_INSISTENT; // keep ringing until stopped

        c.getSystemService(NotificationManager.class).notify(nid(id), n);
        AlarmScheduler.rescheduleAll(c); // book the next day for daily tasks
    }

    static void stop(Context c, long id) {
        c.getSystemService(NotificationManager.class).cancel(nid(id));
    }

    static void markDone(Context c, long id) {
        List<Task> list = TaskStore.load(c);
        Task t = TaskStore.find(list, id);
        if (t != null) {
            t.doneOn.add(Util.today());
            TaskStore.save(c, list);
        }
        AlarmScheduler.rescheduleAll(c);
    }
}
